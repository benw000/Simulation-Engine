# Because I want a fancy name:
class SimulationEngineInputError(Exception):
    pass